﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace StudentManagement
{
    public partial class ManageAttendance : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadCourses();
            }
        }
        private void LoadCourses()
        {
            string connString = ConfigurationManager.ConnectionStrings["MySQLConnection"].ConnectionString;

            using (MySqlConnection conn = new MySqlConnection(connString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT CourseId, CourseName FROM Courses";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    ddlCourses.DataSource = reader;
                    ddlCourses.DataTextField = "CourseName";
                    ddlCourses.DataValueField = "CourseId";
                    ddlCourses.DataBind();
                }
                catch (Exception ex)
                {
                    lblMessage.Text = "Error loading courses: " + ex.Message;
                }
            }
        }

        protected void btnLoadStudents_Click(object sender, EventArgs e)
        {
            int courseId = int.Parse(ddlCourses.SelectedValue);
            string connString = ConfigurationManager.ConnectionStrings["MySQLConnection"].ConnectionString;

            using (MySqlConnection conn = new MySqlConnection(connString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT StudentId, Name FROM Students WHERE CourseId = @CourseId";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@CourseId", courseId);

                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    gvStudents.DataSource = dt;
                    gvStudents.DataBind();
                }
                catch (Exception ex)
                {
                    lblMessage.Text = "Error loading students: " + ex.Message;
                }
            }
        }

        protected void btnSubmitAttendance_Click(object sender, EventArgs e)
        {
            int courseId = int.Parse(ddlCourses.SelectedValue);
            DateTime attendanceDate;

            if (!DateTime.TryParse(txtDate.Text, out attendanceDate))
            {
                lblMessage.Text = "Invalid date format.";
                return;
            }

            string connString = ConfigurationManager.ConnectionStrings["MySQLConnection"].ConnectionString;

            using (MySqlConnection conn = new MySqlConnection(connString))
            {
                try
                {
                    conn.Open();

                    foreach (GridViewRow row in gvStudents.Rows)
                    {
                        int studentId = int.Parse(row.Cells[0].Text);
                        bool isPresent = ((CheckBox)row.FindControl("chkIsPresent")).Checked;

                        string query = "INSERT INTO Attendance (StudentId, CourseId, AttendanceDate, IsPresent) " +
                                       "VALUES (@StudentId, @CourseId, @AttendanceDate, @IsPresent)";
                        MySqlCommand cmd = new MySqlCommand(query, conn);
                        cmd.Parameters.AddWithValue("@StudentId", studentId);
                        cmd.Parameters.AddWithValue("@CourseId", courseId);
                        cmd.Parameters.AddWithValue("@AttendanceDate", attendanceDate);
                        cmd.Parameters.AddWithValue("@IsPresent", isPresent);

                        cmd.ExecuteNonQuery();
                    }

                    lblMessage.ForeColor = System.Drawing.Color.Green;
                    lblMessage.Text = "Attendance submitted successfully!";
                }
                catch (Exception ex)
                {
                    lblMessage.Text = "Error submitting attendance: " + ex.Message;
                }
            }
        }
    }
}