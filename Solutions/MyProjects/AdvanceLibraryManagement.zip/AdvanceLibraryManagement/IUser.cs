﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AdvanceLibraryManagement
{
    public interface IUser
    {
        void BorrowBook(Book book);
        bool ReturnBook(Book book);
        List<Book> GetBorrowedBooks();
    }
}
