﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using FileLogger;
using ExtensionLibrary;

namespace AdvanceLibraryManagement
{
    public class Library
    {
        private ConcurrentDictionary<string, Book> books = new ConcurrentDictionary<string, Book>();
        private readonly object bookLock = new object();
        public bool AddBook(Book book)
        {
            return books.TryAdd(book.ISBN, book);
        }

        public bool RemoveBook(string isbn)
        {
            return books.TryRemove(isbn, out _);
        }

        public void SearchBooks(string searchTerm)
        {
            var results = books.Values
                          .Where(book => (searchTerm.ToLower().Equals("available") && book.IsAvailable) ||
                           (searchTerm.ToLower().Equals("unavailable") && !book.IsAvailable) ||
                           (!string.IsNullOrEmpty(book.Genre) && book.Genre.ToLower().Contains(searchTerm.ToLower()))||
                           (book?.Title?.ToLower().Contains(searchTerm.ToLower()) ?? false) ||
                           (book?.Author?.ToLower().Contains(searchTerm.ToLower()) ?? false)||
                          ( book?.ISBN?.ToLower().Contains(searchTerm.ToLower()) ?? false));

            Console.WriteLine($"Search results for '{searchTerm}':");
            if (!results.Any())
            {
                Console.WriteLine("No matching books found.");
            }
            else
            {
                foreach (var book in results)
                {
                    Console.WriteLine($"    - ISBN: {book.ISBN}, {book.Title} by {book.Author} (Availability Status: {book.IsAvailable})");
                }
            }

        }

        public bool BorrowBook(User user, string isbn)
        {
            lock(bookLock)
            {
                if (books.TryGetValue(isbn, out var book) && book.IsAvailable)
                {
                    user.BorrowBook(book);
                    return true;
                }
                else
                {
                    Console.WriteLine($"'{book?.Title}' is already borrowed by {book?.Borrower.Name}.");
                    Logger.Debug($"'{book?.Title}' is already borrowed by {book?.Borrower.Name}.");
                }
                return false;
            }
            
        }

        public List<Book> GetAvailableBooks()
        {
            return books.Values.Where(book => book.IsAvailable).ToList();
        }

        public List<Book> GetBorrowedBooksByUser(User user)
        {
            return user.GetBorrowedBooks();
        }

        public bool ReturnBook(User user,string isbn)
        {
            lock(bookLock)
            {
                if(books.TryGetValue(isbn,out var book) && !book.IsAvailable)
            {
                if (user.ReturnBook(book))
                {
                    return true;
                }
                else return false;
                
            }
            else
            {

                Console.WriteLine($"You cannot return '{book?.Title}' because it was borrowed by {book?.Borrower.Name}.");
                Logger.Debug($"You cannot return '{book?.Title}' because it was borrowed by {book?.Borrower.Name}.");
            }
            return false;
            }
        }
        public Library()
        {
            InitializeDefaultBooks();
        }
        public void InitializeDefaultBooks()
        {
            AddBook(new Book()
            {
                Title = "Trulu Devious",
                ISBN = "978-0062338068",
                Author = "Maureen Johnson",
                Genre = "Fiction"

            });
            AddBook(new Book(title: "The Risk", "Abby S.T", isbn: "979-8212555555", "Fiction"));
            AddBook(new Book("They Both Die at the End", "Adam Silvera", "978-1471166204", "Fiction"));
            AddBook(new Book("Holding Up The Universe", "Jennifer Niven", "978-0141357058","Fiction"));
            AddBook(new Book("Reckless", "Sidney Sheldon", "978-0008146849","Fiction"));
            AddBook(new Book("The Power of Your Subconscious Mind", "Joseph Murphy", "978-8194790839","Non-Fiction"));
            AddBook(new Book("The Merchant of Venice", "William Shakespeare", "978-9380816296", "Fiction"));
            AddBook(new Book("The Theory of Everything", "Stephen W Hawking", "978-8179925911", "Non-Fiction"));
            Logger.Debug("Default Books are present in the Library");
        }
    }
}
