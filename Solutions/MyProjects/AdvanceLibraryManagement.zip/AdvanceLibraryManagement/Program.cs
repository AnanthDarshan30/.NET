﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using FileLogger;
using ExtensionLibrary;

namespace AdvanceLibraryManagement
{
    public class Program
    {
        static User GetUserByName(string userName, User user1, User user2)
        {
            if (userName == user1.Name.ToLower())
            {
                return user1;
            }
            else if (userName == user2.Name.ToLower())
            {
                return user2;
            }
            else
            {
                Logger.Warning("Invalid User Login.");
                Console.WriteLine("Invalid user. Please enter the right username.");
                return null;
            }
        }

        static async Task Main(string[] args)
        {
            Logger.Configure(@"C:\Users\aadars\SampleFiles\log.txt");

            Console.Write("Enter the user1: ");
            string name = Console.ReadLine();
            User user1 = new User(name);

            Console.Write("Enter the user2: ");
            string name2 = Console.ReadLine();
            User user2 = new User(name2);

            Library library = new Library();

            bool exit = false;

            while (!exit)
            {
                Console.WriteLine("\nLibrary Management System:");
                Console.WriteLine("1. Display Available Books");
                Console.WriteLine("2. Borrow Book");
                Console.WriteLine("3. Return Book");
                Console.WriteLine("4. Search Books");
                Console.WriteLine("5. View Borrowed Books by User");
                Console.WriteLine("6. Add Book");
                Console.WriteLine("7. Remove Book");
                Console.WriteLine("8. Exit");
                Console.Write("Enter your choice: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.WriteLine("Available Books:");

                        Task.Run(() => DisplayAvailableBooks(library)).Wait();
                        break;
                    
                    case "2":
                        Console.Write("Enter ISBN of the book to borrow: ");
                        string isbnBorrow = Console.ReadLine();
                        Console.Write($"Enter User : ");
                        string userChoiceBorrow = Console.ReadLine().ToLower();
                        User selectedUserBorrow = GetUserByName(userChoiceBorrow, user1, user2);
                        
                        var task1 = Task.Run(() => BorrowBook(library, selectedUserBorrow, isbnBorrow));
                        await task1;
                        break;

                    case "3":
                        Console.Write("Enter ISBN of the book to return: ");
                        string isbnReturn = Console.ReadLine();
                        Console.Write($"Enter User : ");
                        string userChoiceReturn = Console.ReadLine().ToLower();
                        User selectedUserReturn = GetUserByName(userChoiceReturn, user1, user2);

                        var task2 = Task.Run(() => ReturnBook(library, selectedUserReturn, isbnReturn));
                        await task2;
                        break;

                    case "4":
                        Console.Write("Enter search term (available/unavailable or title/author/genre): ");
                        string searchTerm = Console.ReadLine();

                        var task3 = Task.Run(() => library.SearchBooks(searchTerm));
                        await task3;
                        break;

                    case "5":
                        Console.Write($"Enter User : ");
                        string userChoiceView = Console.ReadLine().ToLower();
                        User selectedUserView = GetUserByName(userChoiceView, user1, user2);

                        var task4 = Task.Run(() => DisplayBorrowedBooks(selectedUserView));
                        await task4;
                        break;

                    case "6":
                        Console.Write("Enter the Title of the Book to add: ");
                        string title = Console.ReadLine().ToParaCase();
                        Console.Write("Enter the Author of the Book to add: ");
                        string author = Console.ReadLine().ToParaCase();
                        Console.Write("Enter the Genre of the Book to add: ");
                        string genre = Console.ReadLine().ToParaCase();
                        Console.Write("Enter the ISBN of the Book to add: ");
                        string isbn = Console.ReadLine().ToParaCase();
                        Book book = new Book(title,author,isbn,genre);

                        bool result = await Task.Run(() => library.AddBook(book));

                        if (result)
                        {
                            Console.WriteLine($"{book.Title} was succefully added.");
                        }
                        else
                        {
                            Console.WriteLine("Could not add the book.");
                        }

                        break;

                    case "7":
                        Console.Write("Enter the isbn of the book to remove: ");
                        string isbnRemove = Console.ReadLine();
                        bool resultRemove = await Task.Run(() => library.RemoveBook(isbnRemove));
                        if (resultRemove) Console.WriteLine($"book was removed.");
                        else Console.WriteLine("No respective book present in the Library.");
                        break;
                    case "8":
                        exit = true;
                        Console.WriteLine("Exiting...");
                        break;

                    default:
                        Console.WriteLine("Invalid choice. Please select again.");
                        break;
                }
            }
        }

        static void BorrowBook(Library library, User user, string isbn)
        {
            if (library.BorrowBook(user, isbn))
            {
                Logger.Debug($"{user.Name} successfully borrowed the book with ISBN {isbn}.");
                Console.WriteLine($"{user.Name} successfully borrowed the book with ISBN {isbn}.");
            }
            else
            {
                Console.WriteLine($"The book with ISBN {isbn} is not available or does not exist.");
                Logger.Debug($"The book with ISBN {isbn} is not available or does not exist.");
            }
        }

        static void ReturnBook(Library library, User user, string isbn)
        {
            if (library.ReturnBook(user, isbn))
            {
                Logger.Debug($"{user.Name} successfully returned the book with ISBN {isbn}.");
                Console.WriteLine($"{user.Name} successfully returned the book with ISBN {isbn}.");
            }
            else
            {
                Logger.Debug($"The book with ISBN {isbn} could not be returned or is already available.");
                Console.WriteLine($"The book with ISBN {isbn} could not be returned or is already available.");
            }
        }

        static void DisplayAvailableBooks(Library library)
        {
            var availableBooks = library.GetAvailableBooks();
            if (availableBooks.Count > 0)
            {
                foreach (var book in availableBooks)
                {
                    Console.WriteLine($"ISBN: {book.ISBN}, Title: {book.Title}, Author: {book.Author}, Genre: {book.Genre}");
                }
            }
            else
            {
                Console.WriteLine("No books are currently available.");
            }
        }

        static void DisplayBorrowedBooks(User user)
        {
            var borrowedBooks = user.GetBorrowedBooks();
            if (borrowedBooks.Count > 0)
            {
                foreach (var book in borrowedBooks)
                {
                    Console.WriteLine($"ISBN: {book.ISBN}, Title: {book.Title}, Author: {book.Author}");
                }
            }
            else
            {
                Console.WriteLine($"{user.Name} has not borrowed any books.");
            }
        }
    }
}
