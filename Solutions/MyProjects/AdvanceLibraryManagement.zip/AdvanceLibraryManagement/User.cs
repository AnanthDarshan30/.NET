﻿using FileLogger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AdvanceLibraryManagement
{
    public class User : IUser 
    {
        public string Name { get; set; }
        private List<Book> borrowedBooks;

        public User(string name)
        {
            Name = name;
            borrowedBooks = new List<Book>();
        }

        public void BorrowBook(Book book)
        {
            borrowedBooks.Add(book);
            book.IsAvailable = false;
            book.Borrower = this;
        }

        public bool ReturnBook(Book book)
        {
            if(book.Borrower == this)
            {
                borrowedBooks.Remove(book);
                book.IsAvailable = true;
                book.Borrower = null;
                return true;
            }
            else
            {
                Console.WriteLine($"You cannot return '{book.Title}' because it was borrowed by {book.Borrower.Name}.");
                return false;
            }
        }

        public List<Book> GetBorrowedBooks()
        {
            return borrowedBooks;
        }
    }
}
